using System.Threading;
using System.Threading.Tasks;
using GolfWarehouse.Domain.Entities;
using Microsoft.EntityFrameworkCore.Storage;

namespace GolfWarehouse.Application.Interfaces
{
    public interface IPsDocRepository
    {
        Task AddAsync(PsDocHeader doc);
    }

    public interface IPsDocLinRepository
    {
        Task AddRangeAsync(System.Collections.Generic.IEnumerable<PsDocLin> lines);
    }

    public interface IUnitOfWork
    {
        IPsDocRepository PsDocs { get; }
        IPsDocLinRepository PsDocLines { get; }
        Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);

        Task<IDbContextTransaction> BeginTransactionAsync();
        Task CommitTransactionAsync();
        Task RollbackTransactionAsync();
    }
}
