using GolfWarehouse.Application.Dto;
using GolfWarehouse.Application.Interfaces;
using GolfWarehouse.Domain.Entities;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GolfWarehouse.Application.Services
{
    public class PosService
    {
        private readonly IUnitOfWork _uow;
        private readonly ILogger<PosService> _logger;

        public PosService(IUnitOfWork uow, ILogger<PosService> logger)
        {
            _uow = uow ?? throw new ArgumentNullException(nameof(uow));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<long> CreateTransactionAsync(PosTransactionDto dto)
        {
            await _uow.BeginTransactionAsync();

            try
            {
                if (dto == null)
                {
                    _logger.LogInformation("Payload is empty");
                    throw new ArgumentNullException(nameof(dto));
                }

                long docId = Convert.ToInt64(DateTime.UtcNow.ToString("yyyyMMddHHmmss"));//Get unique if base on date

                var doc = new PsDocHeader
                {
                    DOC_ID = docId,
                    STR_ID = dto.StoreId,
                    STA_ID = dto.Sta_Id,
                    TKT_NO = dto.TktNo,
                    DOC_TYP = dto.Doc_Typ,
                    LIN_TOT = dto.Lin_Tot,
                    DOC_GUID = Guid.NewGuid()
                };

                int seq = 1;
                var line = dto.Lines.Select(l => new PsDocLin
                {
                    DOC_ID = docId,
                    LIN_SEQ_NO = seq++,
                    ITEM_NO = l.ItemNo,
                    DESCR = l.Descr,
                    QTY_SOLD = l.QtySold,
                    RETAIL_VAL = l.RetailVal,
                    STK_LOC_ID = l.StkLocId,
                    STR_ID = l.STR_ID,
                    STA_ID = l.STA_ID,
                    TKT_NO = l.TKT_NO,
                    LIN_TYP = l.LIN_TYP,
                    PRC = l.PRC,
                    UNIT_COST = l.UNIT_COST,
                    EXT_PRC = l.EXT_PRC,
                    QTY_NUMER = l.QTY_NUMER,
                    QTY_DENOM = l.QTY_DENOM,
                    SELL_UNIT = l.SELL_UNIT,
                    IS_TXBL = l.IS_TXBL,
                    TRK_METH = l.TRK_METH,
                    ITEM_TYP = l.ITEM_TYP,
                    LIN_GUID = l.LIN_GUID,
                    QTY_RET = l.QTY_RET,
                    GROSS_EXT_PRC = l.GROSS_EXT_PRC,
                    HAS_PRC_OVRD = l.HAS_PRC_OVRD,
                    IS_DISCNTBL = l.IS_DISCNTBL,
                    CALC_EXT_PRC = l.CALC_EXT_PRC,
                    IS_WEIGHED = l.IS_WEIGHED,
                    TAX_AMT_ALLOC = l.TAX_AMT_ALLOC,
                    NORM_TAX_AMT_ALLOC = l.NORM_TAX_AMT_ALLOC
                }).ToList();

                doc.Lines = line;

                await _uow.PsDocs.AddAsync(doc);
                await _uow.PsDocLines.AddRangeAsync(line);

                await _uow.SaveChangesAsync();

                await _uow.CommitTransactionAsync();
                _logger.LogInformation("Successfully inserted");
                return docId;
            }
            catch (Exception ex)
            {
                _logger.LogInformation("Encounter an error: Please check exception " + ex.Message);
                await _uow.RollbackTransactionAsync();
                return 0;
            }
        }
    }
}
