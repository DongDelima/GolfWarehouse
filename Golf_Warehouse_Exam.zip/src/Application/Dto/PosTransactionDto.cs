using System;
using System.Collections.Generic;

namespace GolfWarehouse.Application.Dto
{
    public class PosTransactionDto
    {
        public string Doc_Id{ get; set; } = default!;
        public string StoreId { get; set; } = default!;
        public string TktNo { get; set; } = default!;
        public string Sta_Id { get; set; } = default!;
        public string Doc_Typ { get; set; } = default!;
        public string Lin_Tot { get; set; } = default!;
        public List<PosLineDto> Lines { get; set; } = new List<PosLineDto>();
    }

    public class PosLineDto
    {
        public string ItemNo { get; set; } = default!;
        public string Descr { get; set; }
        public decimal QtySold { get; set; }
        public decimal RetailVal { get; set; }
        public string StkLocId { get; set; } = default!;
        public long DOC_ID { get; set; } = default!;
        public int LIN_SEQ_NO { get; set; } = default!;
        public string STR_ID { get; set; } = default!;
        public string STA_ID { get; set; } = default!;
        public string TKT_NO { get; set; } = default!;
        public string LIN_TYP { get; set; } = default!;
        public decimal PRC { get; set; } = default!;
        public string ITEM_NO { get; set; } = default!;
        public decimal RETAIL_VAL { get; set; } = default!;
        public decimal QTY_SOLD { get; set; } = default!;
        public string STK_LOC_ID { get; set; } = default!;
        public decimal UNIT_COST { get; set; } = default!;
        public decimal EXT_PRC { get; set; } = default!;
        public decimal QTY_NUMER { get; set; } = default!;
        public decimal QTY_DENOM { get; set; } = default!;
        public string SELL_UNIT { get; set; } = default!;
        public bool IS_TXBL { get; set; } = default!;
        public string TRK_METH { get; set; } = default!;
        public string ITEM_TYP { get; set; } = default!;
        public Guid LIN_GUID { get; set; } = default!;
        public decimal QTY_RET { get; set; } = default!;
        public decimal GROSS_EXT_PRC { get; set; } = default!;
        public bool HAS_PRC_OVRD { get; set; } = default!;
        public bool IS_DISCNTBL { get; set; } = default!;
        public decimal CALC_EXT_PRC { get; set; } = default!;
        public bool IS_WEIGHED { get; set; } = default!;
        public decimal TAX_AMT_ALLOC { get; set; } = default!;
        public decimal NORM_TAX_AMT_ALLOC { get; set; } = default!;
    }
}