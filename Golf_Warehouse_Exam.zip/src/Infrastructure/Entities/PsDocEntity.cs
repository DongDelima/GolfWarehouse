using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace GolfWarehouse.Infrastructure.Entities
{
    [Table("PS_DOC_HDR")]
    public class PsDocEntity
    {
        public long DOC_ID { get; set; }
        public string DOC_TYP { get; set; }
        public string STR_ID { get; set; }
        public string STA_ID { get; set; }
        public string TKT_NO { get; set; }
        public string LIN_TOT { get; set; }
        public Guid DOC_GUID { get; set; }
        public ICollection<PsDocLinEntity> Lines { get; set; } = new List<PsDocLinEntity>();

    }
}
