using System.ComponentModel.DataAnnotations.Schema;

namespace GolfWarehouse.Infrastructure.Entities
{
    [Table("IM_INV")]
    public class ImInvEntity
    {
        public string ITEM_NO { get; set; } = default!;
        public string LOC_ID { get; set; } = default!;
        public decimal MIN_QTY { get; set; }
        public decimal QTY_ON_HND { get; set; }
        public decimal AVG_COST { get; set; }
    }
}
