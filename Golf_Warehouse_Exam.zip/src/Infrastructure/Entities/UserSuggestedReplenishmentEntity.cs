using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace GolfWarehouse.Infrastructure.Entities
{

    //Removed. No need to create table. i run the script manually in database 
    //[Table("USER_SUGGESTED_REPLENISHMENT")]
    //public class UserSuggestedReplenishmentEntity
    //{
    //    public long ID { get; set; }
    //    public string ITEM_ID { get; set; } = default!;
    //    public string LOCATION_ID { get; set; } = default!;
    //    public int SUGGESTED_QTY { get; set; }
    //    //public DateTime CREATED_AT { get; set; }
    //    public string? REASON { get; set; }
    //}
}
