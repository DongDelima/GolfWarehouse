using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using GolfWarehouse.Infrastructure.Entities;

namespace GolfWarehouse.Infrastructure.Configurations
{
    public class PsDocLinConfiguration : IEntityTypeConfiguration<PsDocLinEntity>
    {
        public void Configure(EntityTypeBuilder<PsDocLinEntity> builder)
        {
            builder.ToTable("PS_DOC_LIN");
            builder.HasKey(e => new { e.DOC_ID, e.LIN_SEQ_NO });

            builder.Property(e => e.DOC_ID).HasColumnName("DOC_ID").HasMaxLength(50);
            builder.Property(e => e.LIN_SEQ_NO).HasColumnName("LIN_SEQ_NO").IsRequired();
            builder.Property(e => e.ITEM_NO).HasColumnName("ITEM_NO").HasMaxLength(20);
            builder.Property(e => e.DESCR).HasColumnName("DESCR").HasMaxLength(200);
            builder.Property(e => e.QTY_SOLD).HasColumnName("QTY_SOLD").HasColumnType("decimal(15,4)"); 
            builder.Property(e => e.STK_LOC_ID).HasColumnName("STK_LOC_ID").HasMaxLength(10);
            builder.Property(e => e.UNIT_COST).HasColumnName("UNIT_COST").HasColumnType("decimal(15,2)"); 
            builder.Property(e => e.RETAIL_VAL).HasColumnName("RETAIL_VAL").HasColumnType("money");
            builder.Property(e => e.EXT_PRC).HasColumnName("EXT_PRC").HasColumnType("money");

            // Explicit FK mapping
            builder.HasOne(x => x.PsDoc)
                .WithMany(d => d.Lines)
                .HasForeignKey(x => x.DOC_ID)
                .OnDelete(DeleteBehavior.Cascade);


        }
    }
}
