using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using GolfWarehouse.Infrastructure.Entities;

namespace GolfWarehouse.Infrastructure.Configurations
{
    public class PsDocConfiguration : IEntityTypeConfiguration<PsDocEntity>
    {
        public void Configure(EntityTypeBuilder<PsDocEntity> builder)
        {
            builder.ToTable("PS_DOC_HDR");
            builder.HasKey(x => x.DOC_ID);
            builder.Property(x => x.DOC_ID).HasColumnName("DOC_ID").HasMaxLength(50);
        }
    }
}
