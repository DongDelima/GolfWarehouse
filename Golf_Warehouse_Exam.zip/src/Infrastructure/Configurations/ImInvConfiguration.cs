using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using GolfWarehouse.Infrastructure.Entities;

namespace GolfWarehouse.Infrastructure.Configurations
{
    public class ImInvConfiguration : IEntityTypeConfiguration<ImInvEntity>
    {
        public void Configure(EntityTypeBuilder<ImInvEntity> builder)
        {
            builder.ToTable("IM_INV");
            builder.HasKey(e => new { e.ITEM_NO, e.LOC_ID });
            builder.Property(e => e.ITEM_NO).HasColumnName("ITEM_NO").HasMaxLength(20);
            builder.Property(e => e.LOC_ID).HasColumnName("LOC_ID").HasMaxLength(10);
            builder.Property(e => e.MIN_QTY).HasColumnName("MIN_QTY").HasColumnType("decimal(15,4)");
            builder.Property(e => e.QTY_ON_HND).HasColumnName("QTY_ON_HND").HasColumnType("decimal(15,4)");
            builder.Property(e => e.AVG_COST).HasColumnName("AVG_COST").HasColumnType("decimal(15,4)");
        }
    }
}
