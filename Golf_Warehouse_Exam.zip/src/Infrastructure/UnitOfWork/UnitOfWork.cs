using GolfWarehouse.Application.Interfaces;
using GolfWarehouse.Infrastructure.Persistence;
using GolfWarehouse.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using System.Threading;
using System.Threading.Tasks;

namespace GolfWarehouse.Infrastructure.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly GolfWarehouseDbContext _ctx;
        private IDbContextTransaction _currentTransaction;

        public UnitOfWork(GolfWarehouseDbContext ctx)
        {
            _ctx = ctx;
            PsDocs = new PsDocRepository(_ctx);
            PsDocLines = new PsDocLinRepository(_ctx);
        }

        public IPsDocRepository PsDocs { get; }
        public IPsDocLinRepository PsDocLines { get; }

        public async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
            => await _ctx.SaveChangesAsync(cancellationToken);

        public async Task<IDbContextTransaction> BeginTransactionAsync()
        {
            if (_currentTransaction != null)
                return _currentTransaction;

            _currentTransaction = await _ctx.Database.BeginTransactionAsync();
            return _currentTransaction;
        }

        public async Task CommitTransactionAsync()
        {
            try
            {
                await _ctx.SaveChangesAsync();
                await _currentTransaction?.CommitAsync();
            }
            catch
            {
                await RollbackTransactionAsync();
                throw;
            }
            finally
            {
                if (_currentTransaction != null)
                {
                    await _currentTransaction.DisposeAsync();
                    _currentTransaction = null;
                }
            }
        }

        public async Task RollbackTransactionAsync()
        {
            try
            {
                await _currentTransaction?.RollbackAsync();
            }
            finally
            {
                if (_currentTransaction != null)
                {
                    await _currentTransaction.DisposeAsync();
                    _currentTransaction = null;
                }
            }
        }
    }
}
