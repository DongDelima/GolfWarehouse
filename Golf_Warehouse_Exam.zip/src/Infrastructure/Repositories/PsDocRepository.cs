using GolfWarehouse.Application.Interfaces;
using GolfWarehouse.Domain.Entities;
using GolfWarehouse.Infrastructure.Entities;
using GolfWarehouse.Infrastructure.Persistence;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GolfWarehouse.Infrastructure.Repositories
{
    public class PsDocRepository : IPsDocRepository
    {
        private readonly GolfWarehouseDbContext _ctx;
        public PsDocRepository(GolfWarehouseDbContext ctx) => _ctx = ctx;

        public async Task AddAsync(PsDocHeader doc)
        {
            var entity = new PsDocEntity
            {
                DOC_ID = doc.DOC_ID,
                DOC_TYP = doc.DOC_TYP,
                STR_ID = doc.STR_ID,
                STA_ID = doc.STA_ID,
                TKT_NO = doc.TKT_NO,
                LIN_TOT = doc.LIN_TOT,
                DOC_GUID = doc.DOC_GUID
            };

            _ctx.PS_DOC_HDR.Add(entity);
            await Task.CompletedTask;
        }
    }
}
