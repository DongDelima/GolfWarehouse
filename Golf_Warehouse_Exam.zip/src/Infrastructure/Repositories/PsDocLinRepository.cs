using System.Collections.Generic;
using System.Threading.Tasks;
using GolfWarehouse.Application.Interfaces;
using GolfWarehouse.Domain.Entities;
using GolfWarehouse.Infrastructure.Persistence;
using GolfWarehouse.Infrastructure.Entities;
using System.Linq;

namespace GolfWarehouse.Infrastructure.Repositories
{
    public class PsDocLinRepository : IPsDocLinRepository
    {
        private readonly GolfWarehouseDbContext _ctx;
        public PsDocLinRepository(GolfWarehouseDbContext ctx) => _ctx = ctx;

        public async Task AddRangeAsync(IEnumerable<PsDocLin> lines)
        {
            var entities = lines.Select(l => new PsDocLinEntity
            {
                DOC_ID = l.DOC_ID,
                LIN_SEQ_NO = l.LIN_SEQ_NO,
                ITEM_NO = l.ITEM_NO,
                DESCR = l.DESCR,
                QTY_SOLD = l.QTY_SOLD,
                STK_LOC_ID = l.STK_LOC_ID,
                UNIT_COST = l.UNIT_COST,
                RETAIL_VAL = l.RETAIL_VAL,
                EXT_PRC = l.EXT_PRC,
                STR_ID = l.STR_ID,
                STA_ID = l.STA_ID,
                TKT_NO = l.TKT_NO,
                LIN_TYP = l.LIN_TYP,
                PRC = l.PRC,
                QTY_NUMER = l.QTY_NUMER,
                QTY_DENOM = l.QTY_DENOM,
                SELL_UNIT = l.SELL_UNIT,
                IS_TXBL = l.IS_TXBL,
                TRK_METH = l.TRK_METH,
                ITEM_TYP = l.ITEM_TYP,
                LIN_GUID = l.LIN_GUID,
                QTY_RET = l.QTY_RET,
                GROSS_EXT_PRC = l.GROSS_EXT_PRC,
                HAS_PRC_OVRD = l.HAS_PRC_OVRD,
                IS_DISCNTBL = l.IS_DISCNTBL,
                CALC_EXT_PRC = l.CALC_EXT_PRC,
                IS_WEIGHED = l.IS_WEIGHED,
                TAX_AMT_ALLOC = l.TAX_AMT_ALLOC,
                NORM_TAX_AMT_ALLOC = l.NORM_TAX_AMT_ALLOC

            }).ToList();

            await _ctx.PS_DOC_LIN.AddRangeAsync(entities);
        }
    }
}
