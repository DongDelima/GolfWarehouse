using Microsoft.EntityFrameworkCore;
using GolfWarehouse.Infrastructure.Entities;
using GolfWarehouse.Infrastructure.Configurations;

namespace GolfWarehouse.Infrastructure.Persistence
{
    public class GolfWarehouseDbContext : DbContext
    {
        public GolfWarehouseDbContext(DbContextOptions<GolfWarehouseDbContext> options) : base(options) { }

        public DbSet<PsDocEntity> PS_DOC_HDR { get; set; }
        public DbSet<PsDocLinEntity> PS_DOC_LIN { get; set; }
        public DbSet<ImInvEntity> IM_INV { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new PsDocConfiguration());
            modelBuilder.ApplyConfiguration(new PsDocLinConfiguration());
            modelBuilder.ApplyConfiguration(new ImInvConfiguration());
            base.OnModelCreating(modelBuilder);
        }
    }
}
