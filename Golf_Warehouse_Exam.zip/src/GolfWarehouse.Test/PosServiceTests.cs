using FakeItEasy;
using GolfWarehouse.Application.Dto;
using GolfWarehouse.Application.Interfaces;
using GolfWarehouse.Domain.Entities;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using Xunit;

namespace PosService.Tests
{
    public class PosServiceTests
    {
        private readonly IUnitOfWork _fakeUow;
        private readonly ILogger<GolfWarehouse.Application.Services.PosService> _fakeLogger;
        private readonly GolfWarehouse.Application.Services.PosService _service;

        public PosServiceTests()
        {
            _fakeUow = A.Fake<IUnitOfWork>();
            _fakeLogger = A.Fake<ILogger<GolfWarehouse.Application.Services.PosService>>();
            _service = new GolfWarehouse.Application.Services.PosService(_fakeUow, _fakeLogger);
        }


        [Fact]
        public async Task CreateTransactionAsync_ShouldReturnDocId_WhenDtoIsValid()
        {
            long docId = Convert.ToInt64(DateTime.UtcNow.ToString("yyyyMMddHHmmss"));

            string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MockData.json");
            string jsonContent = File.ReadAllText(filePath);

            // Arrange
            var dto = JsonSerializer.Deserialize<PsDocHeader>(jsonContent);


            //var dto = new PosTransactionDto
            //{
            //    Doc_Id = docId.ToString(),
            //    StoreId = "MAIN",
            //    TktNo = "100498",
            //    Sta_Id = "1",
            //    Doc_Typ = "T",
            //    Lin_Tot = "34637.00",
            //    Lines = new List<PosTransactionLineDto>
            //    {
            //        new PosTransactionLineDto
            //        {
            //            ItemNo = "ITEM001",
            //            Descr = "Test Item",
            //            QtySold = 2,
            //            RetailVal = 50,
            //            StkLocId = 1,
            //            STR_ID = 1,
            //            STA_ID = 2,
            //            TKT_NO = "T123",
            //            LIN_TYP = "REG",
            //            PRC = 25,
            //            UNIT_COST = 20,
            //            EXT_PRC = 50,
            //            QTY_NUMER = 2,
            //            QTY_DENOM = 1,
            //            SELL_UNIT = "PCS",
            //            IS_TXBL = true,
            //            TRK_METH = "NONE",
            //            ITEM_TYP = "NORMAL",
            //            LIN_GUID = Guid.NewGuid(),
            //            QTY_RET = 0,
            //            GROSS_EXT_PRC = 50,
            //            HAS_PRC_OVRD = false,
            //            IS_DISCNTBL = true,
            //            CALC_EXT_PRC = 50,
            //            IS_WEIGHED = false,
            //            TAX_AMT_ALLOC = 5,
            //            NORM_TAX_AMT_ALLOC = 5
            //        }
            //    }
            //};

            // Act
            //var result = await _service.CreateTransactionAsync(dto);

            // Assert
            //Assert.NotEqual(0, result);
            //A.CallTo(() => _fakeUow.BeginTransactionAsync()).MustHaveHappenedOnceExactly();
            //A.CallTo(() => _fakeUow.SaveChangesAsync()).MustHaveHappenedOnceExactly();
            //A.CallTo(() => _fakeUow.CommitTransactionAsync()).MustHaveHappenedOnceExactly();
        }

        //[Fact]
        //public async Task CreateTransactionAsync_ShouldThrowException_WhenDtoIsNull()
        //{
        //    // Arrange
        //    PosTransactionDto dto = null;

        //    // Act & Assert
        //    await Assert.ThrowsAsync<ArgumentNullException>(() => _service.CreateTransactionAsync(dto));
        //    A.CallTo(() => _fakeUow.RollbackTransactionAsync()).MustHaveHappenedOnceExactly();
        //}

        //[Fact]
        //public async Task CreateTransactionAsync_ShouldReturnZero_WhenExceptionOccurs()
        //{
        //    // Arrange
        //    var dto = new PosTransactionDto
        //    {
        //        StoreId = 1,
        //        Sta_Id = 2,
        //        TktNo = "T999",
        //        Doc_Typ = "SALE",
        //        Lin_Tot = 200,
        //        Lines = new List<PosTransactionLineDto>()
        //    };

        //    // Force SaveChangesAsync to throw exception
        //    A.CallTo(() => _fakeUow.SaveChangesAsync()).Throws<Exception>();

        //    // Act
        //    var result = await _service.CreateTransactionAsync(dto);

        //    // Assert
        //    Assert.Equal(0, result);
        //    A.CallTo(() => _fakeUow.RollbackTransactionAsync()).MustHaveHappenedOnceExactly();
        //}
    }
}