using FakeItEasy;
using GolfWarehouse.Application.Dto;
using GolfWarehouse.Application.Interfaces;
using GolfWarehouse.Application.Services;
using GolfWarehouse.Domain.Entities;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using System.Text.Json;

namespace GolfWarehouse.Test
{
    public class Service
    {
        private readonly IUnitOfWork _fakeUow;
        private readonly ILogger<PosService> _fakeLogger;
        private readonly PosService _service;

        public Service()
        {
            _fakeUow = A.Fake<IUnitOfWork>();
            _fakeLogger = A.Fake<ILogger<PosService>>();
            _service = new PosService(_fakeUow, _fakeLogger);
        }

        [Fact]
        public async Task CreateTransactionAsync_ShouldReturnDocId_WhenDtoIsValid()
        {
            // Arrange

            //string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MockData.json");
            string filePath = @"C:\Users\HP\Downloads\golf_warehouse_api_persist\src\GolfWarehouse.Test\MockData.json"; //Change the path if yoy want to test
            string jsonContent = await File.ReadAllTextAsync(filePath);
            //var dto = JsonSerializer.Deserialize<PosTransactionDto>(jsonContent);
            //var dto = new PosTransactionDto();

            //JObject jObject = JObject.Parse(jsonContent);

            var dto = JsonSerializer.Deserialize<PosTransactionDto>(jsonContent);

            //long docId = Convert.ToInt64(DateTime.UtcNow.ToString("yyyyMMddHHmmss"));//Get unique if base on date

            //var dto = await JsonSerializer.DeserializeAsync<PosTransactionDto>(jsonContent);


            ////long docId = Convert.ToInt64(DateTime.UtcNow.ToString("yyyyMMddHHmmss"));
            ////var doc = new PsDocHeader
            ////{
            ////    DOC_ID = docId,
            ////    STR_ID = dto.StoreId,
            ////    STA_ID = dto.Sta_Id,
            ////    TKT_NO = dto.TktNo,
            ////    DOC_TYP = dto.Doc_Typ,
            ////    LIN_TOT = dto.Lin_Tot,
            ////    DOC_GUID = Guid.NewGuid()
            ////};

            ////int seq = 1;
            ////var line = dto.Lines.Select(l => new PsDocLin
            ////{
            ////    DOC_ID = docId,
            ////    LIN_SEQ_NO = seq++,
            ////    ITEM_NO = l.ITEM_NO,
            ////    DESCR = l.Descr,
            ////    QTY_SOLD = l.QTY_SOLD,
            ////    RETAIL_VAL = l.RETAIL_VAL,
            ////    STK_LOC_ID = l.STK_LOC_ID,
            ////    STR_ID = l.STR_ID,
            ////    STA_ID = l.STA_ID,
            ////    TKT_NO = l.TKT_NO,
            ////    LIN_TYP = l.LIN_TYP,
            ////    PRC = l.PRC,
            ////    UNIT_COST = l.UNIT_COST,
            ////    EXT_PRC = l.EXT_PRC,
            ////    QTY_NUMER = l.QTY_NUMER,
            ////    QTY_DENOM = l.QTY_DENOM,
            ////    SELL_UNIT = l.SELL_UNIT,
            ////    IS_TXBL = l.IS_TXBL,
            ////    TRK_METH = l.TRK_METH,
            ////    ITEM_TYP = l.ITEM_TYP,
            ////    LIN_GUID = l.LIN_GUID,
            ////    QTY_RET = l.QTY_RET,
            ////    GROSS_EXT_PRC = l.GROSS_EXT_PRC,
            ////    HAS_PRC_OVRD = l.HAS_PRC_OVRD,
            ////    IS_DISCNTBL = l.IS_DISCNTBL,
            ////    CALC_EXT_PRC = l.CALC_EXT_PRC,
            ////    IS_WEIGHED = l.IS_WEIGHED,
            ////    TAX_AMT_ALLOC = l.TAX_AMT_ALLOC,
            ////    NORM_TAX_AMT_ALLOC = l.NORM_TAX_AMT_ALLOC
            ////}).ToList();

            ////doc.Lines = line;

            //var dto = new PosTransactionDto
            //{
            //    StoreId = 1,
            //    Sta_Id = 2,
            //    TktNo = "T123",
            //    Doc_Typ = "SALE",
            //    Lin_Tot = 100,
            //    Lines = new List<PosTransactionLineDto>
            //    {
            //        new PosTransactionLineDto
            //        {
            //            ItemNo = "ITEM001",
            //            Descr = "Test Item",
            //            QtySold = 2,
            //            RetailVal = 50,
            //            StkLocId = 1,
            //            STR_ID = 1,
            //            STA_ID = 2,
            //            TKT_NO = "T123",
            //            LIN_TYP = "REG",
            //            PRC = 25,
            //            UNIT_COST = 20,
            //            EXT_PRC = 50,
            //            QTY_NUMER = 2,
            //            QTY_DENOM = 1,
            //            SELL_UNIT = "PCS",
            //            IS_TXBL = true,
            //            TRK_METH = "NONE",
            //            ITEM_TYP = "NORMAL",
            //            LIN_GUID = Guid.NewGuid(),
            //            QTY_RET = 0,
            //            GROSS_EXT_PRC = 50,
            //            HAS_PRC_OVRD = false,
            //            IS_DISCNTBL = true,
            //            CALC_EXT_PRC = 50,
            //            IS_WEIGHED = false,
            //            TAX_AMT_ALLOC = 5,
            //            NORM_TAX_AMT_ALLOC = 5
            //        }
            //    }
            //};

            //// Act
            //var result = await _service.CreateTransactionAsync(dto);

            //// Assert
            //Assert.NotEqual(0, result);
            //A.CallTo(() => _fakeUow.BeginTransactionAsync()).MustHaveHappenedOnceExactly();
            //A.CallTo(() => _fakeUow.SaveChangesAsync()).MustHaveHappenedOnceExactly();
            //A.CallTo(() => _fakeUow.CommitTransactionAsync()).MustHaveHappenedOnceExactly();
        }

        //[Fact]
        //public async Task CreateTransactionAsync_ShouldThrowException_WhenDtoIsNull()
        //{
        //    // Arrange
        //    PosTransactionDto dto = null;

        //    // Act & Assert
        //    await Assert.ThrowsAsync<ArgumentNullException>(() => _service.CreateTransactionAsync(dto));
        //    A.CallTo(() => _fakeUow.RollbackTransactionAsync()).MustHaveHappenedOnceExactly();
        //}

        //[Fact]
        //public async Task CreateTransactionAsync_ShouldReturnZero_WhenExceptionOccurs()
        //{
        //    // Arrange
        //    var dto = new PosTransactionDto
        //    {
        //        StoreId = 1,
        //        Sta_Id = 2,
        //        TktNo = "T999",
        //        Doc_Typ = "SALE",
        //        Lin_Tot = 200,
        //        Lines = new List<PosTransactionLineDto>()
        //    };

        //    // Force SaveChangesAsync to throw exception
        //    A.CallTo(() => _fakeUow.SaveChangesAsync()).Throws<Exception>();

        //    // Act
        //    var result = await _service.CreateTransactionAsync(dto);

        //    // Assert
        //    Assert.Equal(0, result);
        //    A.CallTo(() => _fakeUow.RollbackTransactionAsync()).MustHaveHappenedOnceExactly();
        //}
    }
}