using GolfWarehouse.Application.Interfaces;
using GolfWarehouse.Application.Services;
using GolfWarehouse.Infrastructure.Persistence;
using GolfWarehouse.Infrastructure.UnitOfWork;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;

namespace GolfWarehouse.Api
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public Startup(IConfiguration configuration) => Configuration = configuration;

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();

            services.AddDbContext<GolfWarehouseDbContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("GolfWarehouseDb")));

            services.AddScoped<IUnitOfWork, UnitOfWork>();
            services.AddScoped<PosService>();

            
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "Golf Warehouse POS API",
                    Version = "v1",
                    Description = "Micro API for processing Point-of-Sale transactions"
                });
            });

        }

        public void Configure(Microsoft.AspNetCore.Builder.IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();

                // Enable middleware to serve Swagger JSON and Swagger UI
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Golf Warehouse POS API v1");
                    c.RoutePrefix = string.Empty; // Swagger at root: https://localhost:5001/
                });
            }

            app.UseRouting();
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Golf Warehouse POS API v1");
            });

            app.UseEndpoints(endpoints => endpoints.MapControllers());
        }
    }
}
