using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using GolfWarehouse.Application.Services;
using GolfWarehouse.Application.Dto;

namespace GolfWarehouse.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PosController : ControllerBase
    {
        private readonly PosService _service;
        public PosController(PosService service) => _service = service;

        [HttpPost("transactions") ]
        public async Task<IActionResult> PostTransaction([FromBody] PosTransactionDto dto)
        {
            if (dto == null) return BadRequest("Payload required");

            var docId = await _service.CreateTransactionAsync(dto);
            return Ok(new { status = "created", docId });
        }
    }
}
