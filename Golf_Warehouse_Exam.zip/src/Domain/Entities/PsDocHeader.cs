using System;
using System.Collections.Generic;

namespace GolfWarehouse.Domain.Entities
{
    public class PsDocHeader
    {
        public long DOC_ID { get; set; } = default!;
        public string DOC_TYP { get; set; }
        public string STR_ID { get; set; }
        public string STA_ID { get; set; }
        public string TKT_NO { get; set; }
        public string LIN_TOT { get; set; }
        public Guid DOC_GUID { get; set; }

        public ICollection<PsDocLin> Lines { get; set; } = new List<PsDocLin>();
    }
}
