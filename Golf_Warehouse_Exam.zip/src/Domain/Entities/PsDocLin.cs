using System;

namespace GolfWarehouse.Domain.Entities
{
    public class PsDocLin
    {
        public long DOC_ID { get; set; } = default!;
        public int LIN_SEQ_NO { get; set; }
        public string STR_ID { get; set; }
        public string STA_ID { get; set; }
        public string TKT_NO { get; set; }
        public string LIN_TYP { get; set; }
        public decimal PRC { get; set; }
        public string ITEM_NO { get; set; }
        public string DESCR { get; set; }
        public decimal RETAIL_VAL { get; set; }
        public decimal CALC_EXT_PRC { get; set; }
        public decimal QTY_SOLD { get; set; }
        public string STK_LOC_ID { get; set; }
        public decimal UNIT_COST { get; set; }
        public decimal EXT_PRC { get; set; }
        public decimal QTY_NUMER { get; set; }
        public decimal QTY_DENOM { get; set; }
        public string SELL_UNIT { get; set; }
        public bool IS_TXBL { get; set; }
        public string TRK_METH { get; set; }
        public string ITEM_TYP { get; set; }
        public Guid LIN_GUID { get; set; }
        public decimal QTY_RET { get; set; }
        public decimal GROSS_EXT_PRC { get; set; }
        public bool HAS_PRC_OVRD { get; set; }
        public bool USR_ENTD_PRC { get; set; }
        public bool IS_DISCNTBL { get; set; }
        public bool IS_WEIGHED { get; set; }
        public decimal TAX_AMT_ALLOC { get; set; }
        public decimal NORM_TAX_AMT_ALLOC { get; set; }
    }
}
